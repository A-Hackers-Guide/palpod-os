%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-03T18:13:45-07:00*%
%TF.ProjectId,palpod-orb,70616c70-6f64-42d6-9f72-622e6b696361,A0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-03 18:13:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
